/*
 *  linux/lib/errno.c
 *
 *  (C) 1991  Linus Torvalds
 */

int errno;
